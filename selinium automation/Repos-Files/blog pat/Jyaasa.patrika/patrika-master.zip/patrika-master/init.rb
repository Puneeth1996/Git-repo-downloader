APP_ROOT = File.dirname(__FILE__)

$:.unshift( File.join(APP_ROOT, 'lib') )

require 'mailer'

Mailer.new.fire    
    
       