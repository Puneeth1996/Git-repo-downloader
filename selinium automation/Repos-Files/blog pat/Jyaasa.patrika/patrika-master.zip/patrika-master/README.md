# patrika
Patrika is a simple newsletter app for the jyaasa to share blogs/knowledges and other things via newsletter. 
